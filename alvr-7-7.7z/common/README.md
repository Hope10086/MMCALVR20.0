# alvr_common

This crate contains some basic functionality shared across all crates in the workspace. In particular it contains constants, logging front-end, and re-exports frequently-used external dependencies.
