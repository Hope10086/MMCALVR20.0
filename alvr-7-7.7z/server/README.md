# alvr_server

SteamVR driver written in C++ and wrapped into a Rust library. The wrapping is done to use the same cross-patform build system of other ALVR compoents, and to allow to easily extend C++ code with Rust.
