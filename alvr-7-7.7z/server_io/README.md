# alvr_server_io

Contains functionality for data storage and system info retrieval. Shared between server and dashboard executable.
