# alvr_client_core

Rust crate containing all major components for an ALVR client except the XR-API-related code.
