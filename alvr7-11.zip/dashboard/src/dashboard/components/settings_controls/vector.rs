// use super::{SettingContainer, SettingsContext, SettingsResponse};
// use crate::dashboard::DashboardResponse;
// use egui::Ui;
// use serde_json as json;
// use settings_schema::VectorDefault;

// pub struct Vector {}

// impl SettingContainer for Vector {
//     fn ui(
//         &mut self,
//         ui: &mut Ui,
//         session_fragment: json::Value,
//         context: &SettingsContext,
//     ) -> Option<SettingsResponse> {
//         None
//     }
// }
